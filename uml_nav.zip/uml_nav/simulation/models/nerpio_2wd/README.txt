Simply place into ~/.gazebo/models/ and Gazebo should recognize it.
