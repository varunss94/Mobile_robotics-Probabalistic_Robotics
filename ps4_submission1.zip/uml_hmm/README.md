# uml_hmm -- PS4

### **tl;dr**

For a discription on the assignment, read the PS4.odt file.

Quick start:
```
cd ~/catkin_ws
source devel/setup.bash
cd src
git clone https://github.com/uml-comp4510-5490/uml_hmm.git
cd ..
catkin_make
roslaunch uml_hmm hmm.launch
```

Test helper functions *(optional)*
```
rosrun uml_hmm query_cxx
rosrun uml_hmm query_python.py
```

*(These should produce approximately the same answers)*
