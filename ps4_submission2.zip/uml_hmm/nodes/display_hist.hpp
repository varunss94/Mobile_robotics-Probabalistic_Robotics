#include <iostream>
#include <array>
#include <vector>
#include <list>

namespace hmm
{
    template<typename Histogram>
    void display_basic(Histogram hist);
}
